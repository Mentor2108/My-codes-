Compile the file normally:

g++ SE20UCAM041.cpp

To execute:

./a.out 3 6 1 3 0 3 5 6 FIFO
./a.out 4 13 7 0 1 2 0 3 0 4 2 3 0 3 2 OPTIMAL
etc...

MADE BY: Gauransh Khurana