Lab 7 by Gauransh Khurana

All the explanation is done in the program itself using comments.
We can compile the file by writing:

g++ SE20UCAM041.cpp

And execute it by typing:

./a.out <arg1> <arg2>
