package com.adp.expense_management.entity;

public enum ExpenseStatus {
    WAITING_FOR_APPROVAL,
    REJECTED,
    APPROVED,
    PAID;
}
