package com.adp.expense_management.model;

public record EmployeeLogin(
        String email,
        String password
){
}
