package com.adp.expense_management.entity;

public enum TravelType {
	INTERCITY_WITH_FAMILY,
	INTERCITY_WITHOUT_FAMILY,
	INTRACITY_WITH_FAMILY,
	INTRACITY_WITHOUT_FAMILY
}
