package com.adp.expense_management.entity;

public enum ExpenseType {
	FOOD,RELOCATION, FLIGHT, WIFI, MOBILE_BILL, OUTING
}
