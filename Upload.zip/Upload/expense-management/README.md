# expense-management service

This is the expense-management-backend micro-service