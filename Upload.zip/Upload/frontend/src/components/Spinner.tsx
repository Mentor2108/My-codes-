import { SdfBusyIndicator } from "@waypoint/react-components";

export default function Spinner(){
    return(
        <SdfBusyIndicator id="demo-component" size="xl"></SdfBusyIndicator>
    );
}