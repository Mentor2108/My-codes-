# auth service

This is the auth micro-service